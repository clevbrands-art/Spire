tsParticles.load("tsparticles", "assets/particles.json");

const music = document.getElementById("bg-music");
const btn = document.getElementById("play-music");

btn.addEventListener("click", () => {
  music.play();
  btn.style.display = "none";
});